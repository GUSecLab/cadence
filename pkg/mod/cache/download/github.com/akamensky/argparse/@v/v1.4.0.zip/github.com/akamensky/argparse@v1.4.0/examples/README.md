# Examples:

* print - Take a string and print it to stdout
* commands - Basic example of using commands
* commands-advanced - Advanced usage of commands with sub-commands and argument scoping
* required-args - Basic example of required vs optional string arguments
